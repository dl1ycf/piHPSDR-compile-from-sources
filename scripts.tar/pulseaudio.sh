#!/bin/sh

cd $HOME

#
# make (if not yet existing) pulseaudio config director
#
mkdir -p $HOME/.config/pulse

cat > $HOME/.config/pulse/default.pa << '#EOF'
#!/usr/bin/pulseaudio -nF

.include /etc/pulse/default.pa

load-module module-null-sink sink_name=SDR-RX sink_properties="device.description=SDR-RX"
load-module module-null-sink sink_name=SDR-TX sink_properties="device.description=SDR-TX"

set-default-sink    SDR-TX
set-default-source  SDR-RX.monitor

#EOF

pulseaudio -k
sleep 2
pulseaudio -D
