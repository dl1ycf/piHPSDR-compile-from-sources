#!/bin/sh
###########################################################################
#
# GPIO-related stuff
#
# Even the latest version of wiringpi does not fully support the RPi 4
#
# Therefore, set all the GPIO pins to "input with pull-up"
#
###########################################################################
#
cd $HOME

cat > boot_config.txt << '#EOF'
######################################
# setup GPIO pins start
######################################
gpio=4-27=ip,pu
######################################
# setup GPIO pins end
######################################
#EOF
cat /boot/config.txt >> boot_config.txt
sudo cp boot_config.txt /boot/config.txt

rm boot_config.txt
